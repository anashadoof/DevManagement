from http import HTTPStatus
import pytest
from assertions.assertion_base import assert_status_code, assert_response_body_fields
from main import get_user_info, get_user_following

class Test:

    @pytest.mark.parametrize("username", ["nonexistentuser123"])
    def test_get_nonexistent_user(self, username):
        response = get_user_info(username)
        assert_status_code(response, HTTPStatus.NOT_FOUND)

    @pytest.mark.parametrize("username", ["anashadoof"])
    def test_get_user_following(self, username, request):
        response = get_user_following(username)
        assert_status_code(response, HTTPStatus.OK)
        assert_response_body_fields(request, response, rmv_ids=False)

    @pytest.mark.parametrize("username", ["anashadoof"])
    def test_get_user(self, username, request):
        response = get_user_info(username)
        assert_status_code(response, HTTPStatus.OK)
        assert_response_body_fields(request, response, fields_to_ignore=["id"])


